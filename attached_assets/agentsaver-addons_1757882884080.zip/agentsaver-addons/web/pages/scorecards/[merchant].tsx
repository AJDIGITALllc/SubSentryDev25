/**
 * /scorecards/[merchant].tsx
 * ISR page for a single merchant scorecard.
 */
import { GetStaticPaths, GetStaticProps } from 'next';
import Head from 'next/head';
import { getAllMerchantIds, getScorecard, Scorecard } from '../../lib/getScorecard';

export default function MerchantScorecardPage({ data }: { data: Scorecard }) {
  if (!data) return <div>Not found</div>;
  const pct = (n:number)=> `${Math.round(n*100)}%`;

  return (
    <main style={{maxWidth: 840, margin: '40px auto', padding: 16}}>
      <Head>
        <title>{data.displayName} — Cancel Scorecard</title>
        <meta name="description" content={`How hard is it to cancel ${data.displayName}? Win rate, median time, friction flags, and proof badges.`} />
      </Head>
      <h1 style={{fontSize: 28, fontWeight: 600}}>{data.displayName} — Cancel Scorecard</h1>
      <p style={{opacity:.7}}>{data.category}</p>

      <section style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginTop:16}}>
        <div style={{border:'1px solid #eee', padding:12}}>
          <h3>Last 30 Days</h3>
          <div>Win rate: <b>{pct(data.period.last30.winRate)}</b></div>
          <div>Median time: <b>{data.period.last30.medianTimeMinutes}m</b></div>
          <div>Volume: <b>{data.period.last30.volume}</b></div>
        </div>
        <div style={{border:'1px solid #eee', padding:12}}>
          <h3>Last 90 Days</h3>
          <div>Win rate: <b>{pct(data.period.last90.winRate)}</b></div>
          <div>Median time: <b>{data.period.last90.medianTimeMinutes}m</b></div>
          <div>Volume: <b>{data.period.last90.volume}</b></div>
        </div>
      </section>

      <section style={{border:'1px solid #eee', padding:12, marginTop:16}}>
        <h3>Channels & Metrics</h3>
        <div>Preferred channels: {data.channels.join(' • ')}</div>
        <ul>
          {Object.entries(data.metrics.successByChannel).map(([k,v])=> <li key={k}>{k}: {pct(v)}</li>)}
        </ul>
        <div>Escalation: {pct(data.metrics.escalationRate)} • Refund: {pct(data.metrics.refundRate)} • Evidence completeness: {pct(data.metrics.evidenceCompletenessPct)}</div>
      </section>

      <section style={{border:'1px solid #eee', padding:12, marginTop:16}}>
        <h3>Friction & Difficulty</h3>
        <div>Difficulty: {data.difficulty}/5</div>
        <ul>{data.frictionFlags.map((f,i)=><li key={i}>{f}</li>)}</ul>
      </section>

      <section style={{border:'1px solid #eee', padding:12, marginTop:16}}>
        <h3>Evidence & How We Cancel</h3>
        <div>Badges: {data.evidenceBadges.join(' • ')}</div>
        {data.howWeCancel && <ol>{data.howWeCancel.map((s,i)=><li key={i}>{s}</li>)}</ol>}
      </section>
    </main>
  );
}

export const getStaticPaths: GetStaticPaths = async () => {
  const ids = await getAllMerchantIds();
  const paths = ids.map(id => ({ params: { merchant: id } }));
  return { paths, fallback: 'blocking' };
};

export const getStaticProps: GetStaticProps = async (ctx) => {
  const merchant = ctx.params?.merchant as string;
  const data = await getScorecard(merchant);
  if (!data) return { notFound: true, revalidate: 3600 };
  return { props: { data }, revalidate: 3600 };
};
