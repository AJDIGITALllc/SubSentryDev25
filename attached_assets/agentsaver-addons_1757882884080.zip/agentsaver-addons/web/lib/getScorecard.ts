/**
 * getScorecard.ts
 * Server-side fetcher for ISR pages.
 * Replace the 'fs' reader with Firestore or S3 as desired.
 */
import fs from 'fs';
import path from 'path';

export type PeriodStats = { winRate:number; medianTimeMinutes:number; volume:number };
export type Scorecard = {
  merchantId:string; displayName:string; category:string;
  period:{ last30:PeriodStats; last90:PeriodStats };
  metrics:{ successByChannel:Record<string,number>; escalationRate:number; refundRate:number; evidenceCompletenessPct:number };
  frictionFlags:string[]; channels:string[]; difficulty:number; evidenceBadges:string[];
  howWeCancel?:string[]; recentUpdates?:string[]; notes?:string;
};

export async function getAllMerchantIds(): Promise<string[]> {
  const dir = path.join(process.cwd(), 'public', 'scorecards');
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter(f => f.endsWith('.json'))
    .map(f => f.replace('.scorecard.json','').replace('.json',''));
}

export async function getScorecard(merchantId: string): Promise<Scorecard|null> {
  const p1 = path.join(process.cwd(), 'public', 'scorecards', `${merchantId}.scorecard.json`);
  const p2 = path.join(process.cwd(), 'public', 'scorecards', `${merchantId}.json`);
  const p = fs.existsSync(p1) ? p1 : p2;
  if (!fs.existsSync(p)) return null;
  const raw = fs.readFileSync(p, 'utf8');
  return JSON.parse(raw);
}
