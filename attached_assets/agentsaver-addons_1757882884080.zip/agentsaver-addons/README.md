# AgentSaver Add-ons

This pack provides:
1) **Next.js ISR pages** for merchant scorecards (`web/pages/scorecards/[merchant].tsx` + `web/lib/getScorecard.ts`).
2) **Cloud Function skeleton** (`functions/computeScorecards.ts`) that aggregates Firestore `tasks` and writes JSON files to a public bucket for the ISR pages.

## Next.js (web/)
- Put JSON files under `public/scorecards/merchantId.scorecard.json`.
- Or switch the loader to Firestore/S3 in `lib/getScorecard.ts`.
- ISR is set to `revalidate: 3600` seconds (1 hour).

## Cloud Function (functions/)
- Expects collections: `merchants` and `tasks` with fields: `state`, `startedAt`, `resolvedAt`, `channelsUsed[]`, `refunded`, `evidenceCount`.
- Env: `SCORECARD_BUCKET` (GCS bucket where JSON files will be written).
- Wrap `scheduledComputeScorecards` with your platform's scheduler (Firebase, Cloud Run jobs, Cron).

## Deploy Sketch
- Firebase Functions (TS):
  ```ts
  import * as functions from 'firebase-functions/v2';
  import { scheduledComputeScorecards } from './computeScorecards.js';
  export const computeScorecardsDaily = functions.scheduler.onSchedule('every 24 hours', async () => {
    return await scheduledComputeScorecards();
  });
  ```
