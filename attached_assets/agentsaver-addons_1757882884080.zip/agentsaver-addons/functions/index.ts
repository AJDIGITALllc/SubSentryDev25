/**
 * index.ts — export a scheduled function.
 * In Firebase Functions, wrap computeScorecards with pubsub.schedule('every 24 hours').onRun(...)
 */
import { computeScorecards } from './computeScorecards.js';

export async function scheduledComputeScorecards() {
  return await computeScorecards();
}
