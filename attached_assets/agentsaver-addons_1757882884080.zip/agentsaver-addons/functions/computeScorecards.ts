/**
 * computeScorecards.ts
 * Cloud Function skeleton that aggregates task data into merchant scorecards,
 * writes JSON into a bucket path or Firestore doc for ISR consumption.
 */
import { Firestore } from '@google-cloud/firestore';
import { Storage } from '@google-cloud/storage';

type Period = 'last30' | 'last90';

const firestore = new Firestore();
const storage = new Storage();
const BUCKET = process.env.SCORECARD_BUCKET || 'agentsaver-scorecards';

export async function computeScorecards() {
  const merchants = await listMerchants();
  for (const m of merchants) {
    const sc = await buildScorecard(m.merchantId);
    await writeToBucket(m.merchantId, sc);
  }
  return { ok: true, count: merchants.length };
}

async function listMerchants(): Promise<{merchantId:string}[]> {
  const snap = await firestore.collection('merchants').get();
  return snap.docs.map(d => ({ merchantId: d.id }));
}

async function buildScorecard(merchantId: string) {
  const periods: Record<Period, number> = { last30: 30, last90: 90 };
  const result: any = {
    merchantId, displayName: merchantId, category: 'Unknown',
    period: {} as any,
    metrics: { successByChannel: {}, escalationRate: 0, refundRate: 0, evidenceCompletenessPct: 0 },
    frictionFlags: [], channels: [], difficulty: 3, evidenceBadges: [],
    recentUpdates: [], notes: ''
  };

  // Fetch recent tasks
  const now = Date.now();
  const tasksSnap = await firestore.collection('tasks').where('merchantId','==',merchantId).get();
  const tasks = tasksSnap.docs.map(d => ({id:d.id, ...d.data()} as any));

  function sliceDays(days:number) {
    const since = now - days*24*3600*1000;
    return tasks.filter(t => (t.resolvedAt ?? t.startedAt ?? now) >= since);
  }

  for (const [label, days] of Object.entries(periods)) {
    const subset = sliceDays(days as any);
    const succeeded = subset.filter(t => t.state === 'succeeded');
    const winRate = subset.length ? succeeded.length / subset.length : 0;
    const medianTime = median(subset.map(t => Math.max(1, ((t.resolvedAt ?? now) - (t.startedAt ?? now)) / 60000)));
    result.period[label] = { winRate, medianTimeMinutes: Math.round(medianTime), volume: subset.length };
  }

  // Channel metrics
  const byChannel: Record<string, {ok:number, total:number}> = {};
  for (const t of tasks) {
    const chs = t.channelsUsed ?? []; // expected array of strings
    const ok = t.state === 'succeeded' ? 1 : 0;
    for (const ch of chs) {
      byChannel[ch] = byChannel[ch] || { ok:0, total:0 };
      byChannel[ch].ok += ok;
      byChannel[ch].total += 1;
    }
  }
  const successByChannel: Record<string, number> = {};
  for (const [k,v] of Object.entries(byChannel)) {
    successByChannel[k] = v.total ? v.ok / v.total : 0;
  }
  result.metrics.successByChannel = successByChannel;
  result.channels = Object.keys(successByChannel).sort();

  // Simple proxies for other metrics
  const escalations = tasks.filter(t => t.state === 'escalated').length;
  result.metrics.escalationRate = tasks.length ? escalations / tasks.length : 0;
  const refunds = tasks.filter(t => t.refunded === true).length;
  result.metrics.refundRate = tasks.length ? refunds / tasks.length : 0;
  const evidenceComplete = tasks.filter(t => (t.evidenceCount ?? 0) >= 2).length;
  result.metrics.evidenceCompletenessPct = tasks.length ? evidenceComplete / tasks.length : 0;

  // Difficulty heuristic (tune later)
  const med90 = result.period.last90?.medianTimeMinutes ?? 60;
  result.difficulty = med90 > 120 ? 5 : med90 > 60 ? 4 : med90 > 30 ? 3 : med90 > 15 ? 2 : 1;

  return result;
}

function median(nums:number[]) {
  if (!nums.length) return 0;
  const s = nums.slice().sort((a,b)=>a-b);
  const mid = Math.floor(s.length/2);
  return s.length % 2 ? s[mid] : (s[mid-1]+s[mid])/2;
}

async function writeToBucket(merchantId:string, json:any) {
  const fileName = `scorecards/${merchantId}.scorecard.json`;
  const buf = Buffer.from(JSON.stringify(json, null, 2), 'utf8');
  const bucket = storage.bucket(BUCKET);
  const file = bucket.file(fileName);
  await file.save(buf, { contentType: 'application/json', resumable: false, public: true });
  return `gs://${BUCKET}/${fileName}`;
}
