import fs from 'fs';
import path from 'path';

async function main() {
  const p = path.join(process.cwd(), 'seed', 'recipes.sample.json');
  const raw = fs.readFileSync(p, 'utf8');
  const recipe = JSON.parse(raw);
  // TODO: write to Firestore collection `recipes`
  console.log('Loaded sample recipe:', recipe.merchantId, 'v', recipe.version);
}

main().catch(e => {
  console.error(e);
  process.exit(1);
});
