# AgentSaver Starter

A thin starter pack for the Agentic Rocket Money clone.

## What’s Inside
- `functions/` – Cloud Functions (TypeScript) with the agent orchestrator, evidence hashing/notarization stubs, pricing, and basic drivers.
- `infra/` – Firestore & Storage rules.
- `seed/` – Sample merchant recipe & seed script.
- `web/` – Placeholder (you can init Next.js here).

## Quickstart
1. Install deps in `functions/`:
   ```bash
   cd functions
   npm init -y
   npm i typescript ts-node @types/node playwright @google-cloud/pubsub @google-cloud/storage jsonschema open-timestamps stripe @sentry/node
   npx tsc --init
   ```

2. Add env in `.env.local` (example below).

3. Run local function (suggest using Firebase Emulators or `ts-node` for quick tests).

## Env (.env.local)
```
PLAID_CLIENT_ID=
PLAID_SECRET=
STRIPE_SECRET=
VOICE_PROVIDER=bland
VOICE_API_KEY=
GMAIL_CLIENT_ID=
GMAIL_CLIENT_SECRET=
GMAIL_REFRESH_TOKEN=
JWT_SIGNING_KEY=dev-secret
GCP_PROJECT_ID=your-project-id
```

## Suggested Next Steps
- Initialize Next.js in `/web` with `create-next-app`.
- Wire Firestore, Stripe webhooks, and Playwright runner.
- Import `seed/recipes.sample.json` via `scripts/seed_recipes.ts`.
