/**
 * Example web step — login descriptor
 */
export const loginStep = {
  channel: 'portal',
  action: 'login',
  selectors: { user: '#email', pass: '#password', submit: '#login' }
};
