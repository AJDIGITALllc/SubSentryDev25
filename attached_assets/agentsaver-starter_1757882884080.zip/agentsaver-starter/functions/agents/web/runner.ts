/**
 * Playwright runner — executes a sequence of steps against a merchant portal.
 */
import { chromium } from 'playwright';

export async function runSteps(steps: any[], secrets: any) {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const artifacts: string[] = [];

  try {
    for (const step of steps) {
      switch (step.action) {
        case 'goto':
          await page.goto(step.url);
          break;
        case 'login':
          await page.fill(step.selectors.user, secrets.user);
          await page.fill(step.selectors.pass, secrets.pass);
          await page.click(step.selectors.submit ?? 'button[type=submit]');
          break;
        case 'click':
          await page.click(step.selectors.btn);
          break;
        case 'screenshot':
          const buf = await page.screenshot();
          // TODO: upload to storage; push URL to artifacts
          artifacts.push('gs://evidence/dev-screenshot.png');
          break;
      }
    }
    return { ok: true, artifacts };
  } catch (e) {
    return { ok: false, error: String(e), artifacts };
  } finally {
    await page.close();
    await browser.close();
  }
}
