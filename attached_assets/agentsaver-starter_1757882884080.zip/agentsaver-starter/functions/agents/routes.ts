/**
 * Channel routes — portal, email, chat, phone, letter (stubs).
 * Implement actual logic in /agents/web/steps and /agents/voice drivers.
 */
export async function tryPortal(ctx:any) {
  // TODO: Playwright runner: login, click cancel, screenshot
  return { ok: false, note: 'not implemented', costDelta: { webMs: 30000 } };
}
export async function tryEmail(ctx:any) {
  // TODO: Send templated email; await ack; store receipt
  return { ok: false, note: 'not implemented' };
}
export async function tryChat(ctx:any) {
  // TODO: Headless chat flow w/ transcript capture
  return { ok: false, note: 'not implemented' };
}
export async function tryPhone(ctx:any) {
  // TODO: Voice driver call; return confirmationId + transcript
  return { ok: false, note: 'not implemented', costDelta: { voiceMin: 3 } };
}
export async function tryLetter(ctx:any) {
  // TODO: Integrate Lob/ClickSend; upload proof of delivery
  return { ok: false, note: 'not implemented', costDelta: { postageCents: 150 } };
}
