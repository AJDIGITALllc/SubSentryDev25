export function computePriceAndMargin(priceCents: number, cost: {webMs:number; voiceMin:number; postageCents:number}) {
  const webCostCents = Math.ceil(cost.webMs / 1000 / 60) * 1; // naive: $0.01/min web time
  const voiceCostCents = Math.ceil(cost.voiceMin) * 10;       // naive: $0.10/min voice
  const postage = cost.postageCents || 0;
  const totalCost = webCostCents + voiceCostCents + postage;
  const marginCents = priceCents - totalCost;
  const marginPct = priceCents > 0 ? Math.round((marginCents / priceCents) * 100) : 0;
  return { totalCost, marginCents, marginPct };
}
