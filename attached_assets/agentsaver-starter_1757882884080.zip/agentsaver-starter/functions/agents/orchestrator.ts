/**
 * AgentSaver Orchestrator — state machine skeleton
 * Routes cancellation tasks across channels with adaptive cost guardrails.
 */
import { computePriceAndMargin } from './pricing.js';
import { Evidence } from './evidence.js';
import { tryPortal, tryEmail, tryChat, tryPhone, tryLetter } from './routes.js';

export type TaskState = 'queued'|'in_progress'|'awaiting_user'|'awaiting_merchant'|'escalated'|'succeeded'|'failed';

export interface TaskCtx {
  taskId: string;
  userId: string;
  subscriptionId: string;
  recipe: any;
  priceCents: number;
  cost: { webMs: number; voiceMin: number; postageCents: number; };
  marginFloorPct: number; // e.g., 40
}

export async function runTask(ctx: TaskCtx): Promise<TaskState> {
  let state: TaskState = 'in_progress';
  const ev = new Evidence(ctx.taskId);

  // cheapest-first routing with guardrails
  const channels = ctx.recipe.channelsOrder as string[];

  for (const channel of channels) {
    const { ok, artifactUrl, note, costDelta } = await route(channel, ctx);
    if (costDelta) addCost(ctx, costDelta);

    if (ok) {
      const passed = await ev.checkSuccessCriteria(ctx.recipe.successCriteria, artifactUrl);
      if (passed) {
        await ev.dualArtifactRequirement(ctx.recipe.evidenceRequirements);
        return 'succeeded';
      }
    }
    // guardrail: stop if projected margin < floor
    const { marginPct } = computePriceAndMargin(ctx.priceCents, ctx.cost);
    if (marginPct < ctx.marginFloorPct) {
      return 'failed';
    }
  }

  // Final escalation path (letter/dispute)
  const { ok } = await tryLetter(ctx);
  if (ok) return 'succeeded';

  return 'failed';
}

function addCost(ctx: TaskCtx, delta: Partial<TaskCtx['cost']>) {
  ctx.cost.webMs += delta.webMs ?? 0;
  ctx.cost.voiceMin += delta.voiceMin ?? 0;
  ctx.cost.postageCents += delta.postageCents ?? 0;
}

async function route(channel: string, ctx: TaskCtx) {
  switch (channel) {
    case 'portal': return await tryPortal(ctx);
    case 'email': return await tryEmail(ctx);
    case 'chat': return await tryChat(ctx);
    case 'phone': return await tryPhone(ctx);
    default: return { ok: false };
  }
}
