export interface VoiceDriver {
  call(opts: {to:string; script:string; recording:boolean;}): Promise<{callId:string; transcriptUrl?:string; summary:string; success:boolean; confirmationId?:string; minutes:number}>;
}
