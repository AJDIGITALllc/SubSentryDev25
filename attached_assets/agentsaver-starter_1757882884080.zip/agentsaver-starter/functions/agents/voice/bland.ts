import type { VoiceDriver } from './index.js';

export const BlandDriver: VoiceDriver = {
  async call(opts) {
    // TODO: invoke Bland AI
    return { callId: 'dev', summary: 'stub', success: false, minutes: 0 };
  }
};
