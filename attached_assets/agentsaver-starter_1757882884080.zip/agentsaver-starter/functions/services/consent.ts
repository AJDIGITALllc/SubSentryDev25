export async function ensureScope(userId:string, scope:'email'|'phone'|'web'|'legal') {
  // throw if user hasn't granted authorized proxy consent for the scope
}
