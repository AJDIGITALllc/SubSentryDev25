export async function getRecipe(merchantId:string) {/* fetch latest version */}
export async function saveRecipe(recipe:any, actor:string) {/* validate + version audit */}
