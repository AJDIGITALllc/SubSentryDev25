export async function linkBankStart() {/* return link token from Plaid */}
export async function linkBankExchange(publicToken:string) {/* exchange for access token */}
export async function listRecurringSubscriptions(userId:string) {/* query db */ return []; }
