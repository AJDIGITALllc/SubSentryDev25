export async function authGuard(ctx:any) {
  if (!ctx.user) throw new Error('Unauthorized');
}
