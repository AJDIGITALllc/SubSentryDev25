export async function consentGuard(ctx:any, scope:'email'|'phone'|'web'|'legal') {
  // verify user consent for given scope
}
