/**
 * Minimal entrypoint — export orchestrator for tests and local runs.
 */
export * from './agents/orchestrator.js';
